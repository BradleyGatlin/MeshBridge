MeshBridge 0.4 — Feature build

Research basis:
- Roblox binary RBXM/RBXL signature and version/chunk structure.
- Roblox XML model structure, Items, Properties, Referents and common value types.
- rbx-dom's documented XML/binary separation.

Features in this build:
- Content-based RBXM/RBXL/RBXMX/RBXLX detection.
- Roblox XML instance tree import.
- Blender collections for imported Roblox files.
- Roblox hierarchy reconstruction from Parent referents.
- Part-like geometry generation.
- Model/Folder/Tool/Workspace containers.
- Humanoid detection metadata.
- Texture/MeshID references tracked in import report.
- Unsupported Roblox classes are preserved as marked Blender empties instead
  of being silently discarded.
- Scripts are never executed.
- Import Report generated as a Blender Text datablock.
- Asset Inspector for imported Roblox metadata.
- Existing MeshBridge clean UI retained.
- Existing Nostro/CMFET backends retained.
- RBXM/RBXL remain import-only.

Important:
The binary loader validates the official binary header and records version,
class count and instance count safely. It does not yet pretend to fully decode
every binary property/chunk. XML is the richer path in this build.
